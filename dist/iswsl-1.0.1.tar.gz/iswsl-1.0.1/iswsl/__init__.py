from iswsl.iswsl import is_wsl
